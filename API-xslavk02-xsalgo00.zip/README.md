# WAPproj2

#### Setup:
    npm i
  
#### Starting server:
    node app.js
  
 #### Execution:
   http://localhost:8080/<query>
